(function(){
	
	const BASEMAP_URL	= "http://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png";
	const DATA_URL		= "https://savi.cartodb.com/u/rylander/api/v2/viz/f02cf620-d05a-11e5-b8f0-0ecd1babdde5/viz.json";
	const ATTRIBUTION	= "&copy; <a href=\"http://www.openstreetmap.org/copyright\">OpenStreetMap</a>\
	 					   contributors, &copy; <a href=\"http://cartodb.com/attributions\">CartoDB</a>";
	const QUERY			= "SELECT * FROM video_locations WHERE published_on >= '2008-01-01' AND published_on <= '2008-12-31'"
	
	// create new leaflet map in cartodb-map element
	var map = new L.Map('cartodb-map', { 
		center: [0,0],
		zoom: 2
	});
	
	// create and add basemap layer to leaflet map
	var baseMapLayer = L.tileLayer( 
		BASEMAP_URL, 
		{attribution: ATTRIBUTION}
	);
	map.addLayer(baseMapLayer);
	
	// prepare data sublayer parameters
	var subLayerOptions = {
		sql: QUERY,
		interaction: true,
		interactivity: "cartodb_id, google_place_name"
	}
	
	// create data layer add it to leaflet map
	cartodb.createLayer(map, DATA_URL)
		.addTo(map)
		.on('done', function(layer) {
			console.log("DONE!");
			var dataSubLayer = layer.getSubLayer(0);
			dataSubLayer.set(subLayerOptions);
			console.log(dataSubLayer);
			console.log("SQL: " + dataSubLayer.getSQL());
			console.log("Interactivity: " + dataSubLayer.getInteractivity());
			console.log(dataSubLayer.getAttributes())
			dataSubLayer.setInteraction(true);
			dataSubLayer.on('featureClick', function(e, latlng, pos, data) {
				("Hey! You clicked " + data.cartodb_id);
			});
		})
		.on('error', function() {
			console.log("error creating data layer");
		});    
	
}());